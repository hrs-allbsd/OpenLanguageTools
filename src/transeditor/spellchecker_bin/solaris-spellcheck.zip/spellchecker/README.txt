This directory contains spellchecker software and dictionaries. The spellchecker software used is
GNU Aspell 0.50.3, by Kevin Atkinson. This software is licensed under the Lesser GNU Public License.
Details of the license can be found in the file COPYING.aspell. The source code for the software is
available from http://aspell.sourceforge.net/ 

The dictionaries come from numerous sources. They are downloadable from the GNU ftp site, which can be
accessed form the http://aspell.net/ website. The dictionaries are licensed under the terms of the 
GNU Public License, and details of the license can be found in the file COPYING.dictionaries. Details
of the copyrights for the various dictionaries are also included in this directory. They appear in the
files Copyright_<lang>_dict, where <lang> is the language code for the dictionary. For example, the
copyright notice for the French dictionaries appear in the file Copyright_fr_dict.
